import subprocess

subprocess.run(["pip", "install", "-r", "requirements.txt"])

from urllib.parse import unquote
import requests
import json

def main():
    while True:
        ini = input("What next?")[33:]
        response = requests.get(f"https://learningapps.org/data?jsonp=1&id={ini}")
        pars = json.loads(response.text[23:len(response.text) - 1])["initparameters"]
        print(unquote(pars[(pars.index("feedback=") + 9):]))

if __name__ == '__main__':
    main()